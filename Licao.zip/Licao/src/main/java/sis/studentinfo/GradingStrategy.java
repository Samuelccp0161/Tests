package sis.studentinfo;

public interface GradingStrategy {
    int getGradePointsFor(Student.Grade grade);
}
