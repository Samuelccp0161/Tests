package sis.report;

public class ReportConstant {
    public static final String NEWLINE =System.getProperty("line.separator");
}
